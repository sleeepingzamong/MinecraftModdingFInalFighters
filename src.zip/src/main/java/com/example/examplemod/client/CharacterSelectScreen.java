package com.example.examplemod.client;

import com.example.examplemod.combat.CharacterType;
import com.example.examplemod.network.ModMessages;
import com.example.examplemod.network.SelectCharacterC2SPacket;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class CharacterSelectScreen extends Screen {

    private CharacterType selectedCharacter = CharacterType.NONE;
    private String selectedName = "선택 안 됨";

    public CharacterSelectScreen() {
        super(Component.literal("캐릭터 선택"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        this.addRenderableWidget(Button.builder(
                Component.literal("원숭이"),
                button -> {
                    selectedCharacter = CharacterType.MONKEY;
                    selectedName = "원숭이";
                }
        ).bounds(centerX - 110, centerY - 30, 100, 30).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("사이보그"),
                button -> {
                    selectedCharacter = CharacterType.CYBORG;
                    selectedName = "사이보그";
                }
        ).bounds(centerX + 10, centerY - 30, 100, 30).build());

        this.addRenderableWidget(Button.builder(
                Component.literal("선택"),
                button -> {
                    if (selectedCharacter != CharacterType.NONE) {
                        ModMessages.sendToServer(new SelectCharacterC2SPacket(selectedCharacter));
                        this.minecraft.setScreen(null);
                    }
                }
        ).bounds(this.width - 90, this.height - 35, 70, 20).build());
    }

    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(guiGraphics);

        guiGraphics.drawCenteredString(
                this.font,
                "캐릭터 선택",
                this.width / 2,
                30,
                0xFFFFFF
        );

        guiGraphics.drawCenteredString(
                this.font,
                "현재 선택: " + selectedName,
                this.width / 2,
                60,
                0xFFFF00
        );

        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}