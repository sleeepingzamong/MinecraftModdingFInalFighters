package com.example.examplemod.client;

import com.example.examplemod.ExampleMod;
import com.example.examplemod.combat.SkillType;
import com.example.examplemod.network.ModMessages;
import com.example.examplemod.network.UseSkillC2SPacket;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(
        modid = ExampleMod.MODID,
        bus = Mod.EventBusSubscriber.Bus.FORGE,
        value = Dist.CLIENT
)
public class ClientSkillKeyEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }

        if (Minecraft.getInstance().screen != null) {
            return;
        }

        while (ModKeyMappings.SKILL_1_KEY.consumeClick()) {
            ModMessages.sendToServer(new UseSkillC2SPacket(SkillType.SKILL_1));
        }

        while (ModKeyMappings.SKILL_2_KEY.consumeClick()) {
            ModMessages.sendToServer(new UseSkillC2SPacket(SkillType.SKILL_2));
        }

        while (ModKeyMappings.ULTIMATE_KEY.consumeClick()) {
            ModMessages.sendToServer(new UseSkillC2SPacket(SkillType.ULTIMATE));
        }
    }
}