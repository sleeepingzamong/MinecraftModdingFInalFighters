package com.example.examplemod.network;

import com.example.examplemod.combat.SkillManager;
import com.example.examplemod.combat.SkillType;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class UseSkillC2SPacket {

    private final SkillType skillType;

    public UseSkillC2SPacket(SkillType skillType) {
        this.skillType = skillType;
    }

    public UseSkillC2SPacket(FriendlyByteBuf buf) {
        this.skillType = SkillType.valueOf(buf.readUtf());
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeUtf(skillType.name());
    }

    public void handle(Supplier<NetworkEvent.Context> supplier) {
        NetworkEvent.Context context = supplier.get();

        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();

            if (player != null) {
                SkillManager.useSkill(player, skillType);
            }
        });

        context.setPacketHandled(true);
    }
}