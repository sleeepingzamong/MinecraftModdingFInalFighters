package com.example.examplemod.network;

import com.example.examplemod.ExampleMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class ModMessages {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel INSTANCE = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ExampleMod.MODID, "messages"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    public static void register() {
        INSTANCE.registerMessage(
                packetId++,
                SelectCharacterC2SPacket.class,
                SelectCharacterC2SPacket::encode,
                SelectCharacterC2SPacket::new,
                SelectCharacterC2SPacket::handle
        );

        INSTANCE.registerMessage(
                packetId++,
                UseSkillC2SPacket.class,
                UseSkillC2SPacket::encode,
                UseSkillC2SPacket::new,
                UseSkillC2SPacket::handle
        );
    }

    public static void sendToServer(Object message) {
        INSTANCE.sendToServer(message);
    }
}