package com.example.examplemod.combat;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class CyborgSkills implements CharacterSkills {

    @Override
    public void useSkill1(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("사이보그 스킬 1 사용!"));
    }

    @Override
    public void useSkill2(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("사이보그 스킬 2 사용!"));
    }

    @Override
    public void useUltimate(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("사이보그 궁극기 사용!"));
    }
}