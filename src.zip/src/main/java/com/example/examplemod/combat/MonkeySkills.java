package com.example.examplemod.combat;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MonkeySkills implements CharacterSkills {

    @Override
public void useSkill1(ServerPlayer player) {
    if (!(player.level() instanceof ServerLevel serverLevel)) {
        return;
    }

    Vec3 look = player.getLookAngle();

    Vec3 direction = new Vec3(look.x, 0, look.z).normalize();

    if (direction.lengthSqr() == 0) {
        return;
    }

    Set<LivingEntity> hitEntities = new HashSet<>();

    double startX = player.getX();
    double startY = player.getY() + 1.0;
    double startZ = player.getZ();

    for (int i = 1; i <= 10; i++) {
        Vec3 center = new Vec3(
                startX + direction.x * i,
                startY,
                startZ + direction.z * i
        );

        serverLevel.sendParticles(
                ParticleTypes.EXPLOSION,
                center.x,
                center.y,
                center.z,
                1,
                0.8,
                0.8,
                0.8,
                0.01
        );

        AABB attackBox = AABB.ofSize(
                center,
                3.0,
                3.0,
                3.0
        );

        List<LivingEntity> targets = serverLevel.getEntitiesOfClass(
                LivingEntity.class,
                attackBox,
                entity -> entity.isAlive() && entity != player
        );

        for (LivingEntity target : targets) {
            if (hitEntities.contains(target)) {
                continue;
            }

            target.hurt(player.damageSources().playerAttack(player), 5.0F);
            hitEntities.add(target);
        }
    }

    player.sendSystemMessage(Component.literal("원숭이 스킬 1 사용!"));
}

    @Override
    public void useSkill2(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("원숭이 스킬 2 사용!"));
    }

    @Override
    public void useUltimate(ServerPlayer player) {
        player.sendSystemMessage(Component.literal("원숭이 궁극기 사용!"));
    }
}