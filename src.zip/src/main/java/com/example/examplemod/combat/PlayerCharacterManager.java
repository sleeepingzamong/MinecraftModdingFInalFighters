package  com.example.examplemod.combat;

import net.minecraft.world.entity.player.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerCharacterManager {

    private static final Map<UUID, CharacterType> PLAYER_CHARACTERS = new HashMap<>();

    public static void setCharacter(Player player, CharacterType characterType) {
        PLAYER_CHARACTERS.put(player.getUUID(), characterType);
    }

    public static CharacterType getCharacter(Player player) {
        return PLAYER_CHARACTERS.getOrDefault(player.getUUID(), CharacterType.NONE);
    }
}