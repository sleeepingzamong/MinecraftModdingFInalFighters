package com.example.examplemod.combat;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class SkillManager {

    private static final CharacterSkills MONKEY_SKILLS = new MonkeySkills();
    private static final CharacterSkills CYBORG_SKILLS = new CyborgSkills();

    public static void useSkill(ServerPlayer player, SkillType skillType) {
        CharacterType characterType = PlayerCharacterManager.getCharacter(player);

        CharacterSkills skills = getSkills(characterType);

        if (skills == null) {
            player.sendSystemMessage(Component.literal("캐릭터가 선택되지 않았습니다."));
            return;
        }

        switch (skillType) {
            case SKILL_1 -> skills.useSkill1(player);
            case SKILL_2 -> skills.useSkill2(player);
            case ULTIMATE -> skills.useUltimate(player);
        }
    }

    private static CharacterSkills getSkills(CharacterType characterType) {
        return switch (characterType) {
            case MONKEY -> MONKEY_SKILLS;
            case CYBORG -> CYBORG_SKILLS;
            default -> null;
        };
    }
}