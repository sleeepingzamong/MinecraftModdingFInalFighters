package com.example.examplemod.combat;

import net.minecraft.server.level.ServerPlayer;

public interface CharacterSkills {
    void useSkill1(ServerPlayer player);

    void useSkill2(ServerPlayer player);

    void useUltimate(ServerPlayer player);
}