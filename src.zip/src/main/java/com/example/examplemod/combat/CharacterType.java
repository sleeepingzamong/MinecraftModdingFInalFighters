package com.example.examplemod.combat;
public enum CharacterType{
    NONE,
    MONKEY,
    CYBORG
}